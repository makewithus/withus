"use strict";
(() => {
  // src/providers/platform-registry.ts
  var PlatformRegistry = class {
    constructor() {
      this.configs = /* @__PURE__ */ new Map();
    }
    register(config) {
      this.configs.set(config.id, config);
    }
    getForHost(hostname) {
      for (const config of this.configs.values()) {
        for (const domain of config.domains) {
          if (hostname === domain || hostname.endsWith(`.${domain}`)) {
            return config;
          }
        }
      }
      return null;
    }
    getAll() {
      return Array.from(this.configs.values());
    }
  };
  var platformRegistry = new PlatformRegistry();
  platformRegistry.register({
    id: "GITHUB",
    name: "GitHub",
    domains: ["github.com"],
    login: {
      url: "https://github.com/login",
      usernameSelector: 'input[name="login"], input#login_field',
      passwordSelector: 'input[name="password"], input#password',
      submitSelector: 'input[name="commit"], input[type="submit"], button[type="submit"]'
    },
    principalType: "GITHUB_USERNAME",
    supportsDelegation: true,
    /**
     * Module-level UI restrictions for GitHub.
     *
     * GitHub's repository navigation uses stable data-tab-item attributes
     * that have been consistent across GitHub's design iterations.
     * These are confirmed from the live GitHub repository <nav> outerHTML.
     *
     * Selector strategy:
     *   a[data-tab-item="..."] — direct attribute match on the nav anchor.
     *   These are semantic, non-generated attributes and extremely stable.
     *
     * Scope: Repository-level navigation only (the top tab bar on repo pages).
     * Organisation-level restrictions (People, Org Settings, etc.) require
     * separate outerHTML inspection and will be added as a second step.
     */
    capabilityRestrictions: {
      "github.repo_actions": {
        hideElementsCSS: ['a[data-tab-item="actions"]']
      },
      "github.repo_projects": {
        hideElementsCSS: ['a[data-tab-item="projects"]:not([href^="/orgs/"])']
      },
      "github.repo_security": {
        hideElementsCSS: ['a[data-tab-item="security-and-quality"]']
      },
      "github.repo_wiki": {
        hideElementsCSS: ['a[data-tab-item="wiki"]']
      },
      "github.repo_insights": {
        hideElementsCSS: ['a[data-tab-item="insights"]']
      },
      "github.repo_settings": {
        hideElementsCSS: ['a[data-tab-item="settings"]']
      },
      "github.org_members": {
        hideElementsCSS: ['a[data-tab-item="people"]']
      },
      "github.org_projects": {
        hideElementsCSS: ['a[data-tab-item="projects"][href^="/orgs/"]']
      }
    }
  });
  platformRegistry.register({
    id: "VERCEL",
    name: "Vercel",
    domains: ["vercel.com"],
    login: {
      url: "https://vercel.com/login",
      usernameSelector: 'input[type="email"], input[name="email"]',
      passwordSelector: 'input[type="password"], input[name="password"]',
      submitSelector: 'button[type="submit"]'
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[autocomplete="one-time-code"], input[inputmode="numeric"], input[type="number"], input[name="code"], input[type="text"][maxlength="1"]'
    },
    principalType: "EMAIL",
    supportsDelegation: true,
    capabilityRestrictions: {
      "vercel.domains": {
        hideElementsCSS: ['a[data-sidebar-link-key="Domains"]']
      },
      "vercel.analytics": {
        hideElementsCSS: ['a[data-sidebar-link-key="Analytics"]']
      },
      "vercel.env": {
        hideElementsCSS: ['a[data-sidebar-link-key="Environment Variables"]']
      },
      "vercel.storage": {
        hideElementsCSS: ['a[data-sidebar-link-key="Storage"]']
      },
      "vercel.integrations": {
        hideElementsCSS: ['a[data-sidebar-link-key="Integrations"]']
      },
      "vercel.settings": {
        hideElementsCSS: ['a[data-sidebar-link-key="Settings"]']
      }
    }
  });
  platformRegistry.register({
    id: "GODADDY",
    name: "GoDaddy",
    domains: ["godaddy.com", "sso.godaddy.com"],
    login: {
      url: "https://sso.godaddy.com/",
      usernameSelector: '#username, input[name="username"], input[type="email"]',
      passwordSelector: '#password, input[name="password"], input[type="password"]',
      submitSelector: 'button#submitBtn, button[type="submit"], input[type="submit"]',
      requirePasswordOnDOM: true
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[aria-label="Hide password" i]',
      "#password",
      "div:has(> input#password)"
    ],
    principalType: "EMAIL",
    supportsDelegation: true,
    capabilityRestrictions: {
      "godaddy.domain": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/domain.menu_item.click"]']
      },
      "godaddy.website": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/website.menu_item.click"]']
      },
      "godaddy.email": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/email.menu_item.click"]']
      },
      "godaddy.store": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/store.menu_item.click"]']
      },
      "godaddy.appointments": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/appointments.menu_item.click"]']
      },
      "godaddy.marketing": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/marketing.menu_item.click"]']
      },
      "godaddy.conversations": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/conversations.menu_item.click"]']
      },
      "godaddy.customers": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/customers.menu_item.click"]']
      },
      "godaddy.deals": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/deals.menu_item.click"]']
      },
      "godaddy.users": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/users.menu_item.click"]']
      },
      "godaddy.app_switcher": {
        hideElementsCSS: ['[data-testid="app-switcher-btn"]']
      },
      "godaddy.my_products": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/my_products.menu_item.click"]']
      },
      "godaddy.account_settings": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/account_settings.menu_item.click"]']
      },
      "godaddy.billing": {
        hideElementsCSS: ['[data-eid*="billing.menu_item"], a[href*="billing"]']
      },
      "godaddy.shop": {
        hideElementsCSS: ['[data-eid="pandc.vnext_dashboard.header/shop_godaddycom.menu_item.click"]']
      }
    }
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com", "www.linkedin.com"],
    login: {
      url: "https://www.linkedin.com/checkpoint/lg/login?trk=hb_signin",
      usernameSelector: 'input[name="session_key"], #session_key, input[autocomplete="username"], input[autocomplete="email"], input[type="email"], #username',
      passwordSelector: 'input[name="session_password"], #session_password, input[autocomplete="current-password"], input[type="password"], #password',
      submitSelector: 'button[type="submit"], button[aria-label="Sign in"], .login__form_action_container button'
    }
  });
  platformRegistry.register({
    id: "SHOPIFY",
    name: "Shopify",
    domains: ["shopify.com", "accounts.shopify.com", "admin.shopify.com"],
    login: {
      url: "https://admin.shopify.com/login",
      usernameSelector: 'input[type="email"], input[autocomplete="username"], #account_email',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], #account_password',
      submitSelector: 'button[type="submit"], button[name="commit"]'
    },
    hideElementsCSS: [
      "button.js-password-button",
      'button[aria-controls="account_password"]',
      "#account_password",
      ".password-wrapper:has(#account_password)"
    ],
    capabilityRestrictions: {
      "shopify.orders": {
        hideElementsCSS: ['a[href$="/orders"]']
      },
      "shopify.products": {
        hideElementsCSS: ['a[href$="/products"]']
      },
      "shopify.customers": {
        hideElementsCSS: ['a[href$="/customers"]']
      },
      "shopify.growth": {
        hideElementsCSS: ['a[href$="/growth"]']
      },
      "shopify.discounts": {
        hideElementsCSS: ['a[href$="/discounts"]']
      },
      "shopify.content": {
        hideElementsCSS: ['a[href*="/content"]']
      },
      "shopify.markets": {
        hideElementsCSS: ['a[href$="/markets"]']
      },
      "shopify.analytics": {
        hideElementsCSS: ['a[href$="/analytics"]']
      },
      "shopify.sales_channels": {
        hideElementsCSS: ['a[href*="/themes"]', 'a[href*="/pages"]', 'a[href*="/blogs"]', 'a[href*="/menus"]', 'a[href*="/preferences"]']
      },
      "shopify.apps": {
        hideElementsCSS: ['a[href*="/apps/"]']
      },
      "shopify.settings": {
        hideElementsCSS: ['a[href$="/settings"]']
      }
    }
  });
  platformRegistry.register({
    id: "STRIPE",
    name: "Stripe",
    domains: ["stripe.com", "dashboard.stripe.com"],
    login: {
      url: "https://dashboard.stripe.com/login",
      usernameSelector: 'input[type="email"], input[name="email"], input[autocomplete="username"]',
      passwordSelector: 'input[type="password"], input[name="password"], input[autocomplete="current-password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-testid="login-button"]'
    },
    hideElementsCSS: [
      'input[data-testid="login-password-input"]',
      "#old-password",
      'div:has(> input[data-testid="login-password-input"])',
      "div:has(> input#old-password)"
    ],
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[name="verification_code"]',
      submitSelector: 'button[type="submit"]'
    },
    capabilityRestrictions: {
      "stripe.payments": {
        hideElementsCSS: ['li[data-testid="core-nav-item-payments"]', 'a[data-testid="toggle-workload-payments"]']
      },
      "stripe.customers": {
        hideElementsCSS: ['li[data-testid="core-nav-item-customers"]']
      },
      "stripe.products": {
        hideElementsCSS: ['li[data-testid="core-nav-item-products"]']
      },
      "stripe.balance": {
        hideElementsCSS: ['li[data-testid="core-nav-item-balances"]']
      },
      "stripe.billing": {
        hideElementsCSS: ['a[data-testid="toggle-workload-billing"]']
      },
      "stripe.reports": {
        hideElementsCSS: ['a[data-testid="toggle-workload-reporting"]']
      },
      "stripe.developers": {
        hideElementsCSS: ["section#developer-nav"]
      }
    }
  });
  platformRegistry.register({
    id: "RAZORPAY",
    name: "Razorpay",
    // Only accounts.razorpay.com is the login/auth subdomain.
    // dashboard.razorpay.com is the post-login dashboard, required here so capability enforcer runs on it.
    domains: ["accounts.razorpay.com", "dashboard.razorpay.com"],
    login: {
      url: "https://accounts.razorpay.com/auth",
      usernameSelector: 'input[type="email"], input[type="text"], input[type="tel"], input[autocomplete="username"], input[autocomplete="email"]',
      passwordSelector: 'input[type="password"], input[autocomplete="current-password"], input[placeholder*="password" i]',
      submitSelector: 'button[type="submit"], button#btn-login, #btn-login, button.btn-primary, button[data-testid="btn-submit"]'
    },
    hideElementsCSS: [
      'button[aria-label="Show password" i]',
      'button[data-blade-component="icon-button"] svg'
    ],
    capabilityRestrictions: {
      "razorpay.transactions": { hideElementsCSS: ['a[href="/app/payments"]'] },
      "razorpay.settlements": { hideElementsCSS: ['a[href="/app/settlements"]'] },
      "razorpay.reports": { hideElementsCSS: ['a[href="/app/reports"]'] },
      "razorpay.payment_links": { hideElementsCSS: ['a[href="/app/paymentlinks"]'] },
      "razorpay.payment_pages": { hideElementsCSS: ['a[href="/app/paymentpages"]'] },
      "razorpay.invoices": { hideElementsCSS: ['a[href="/app/invoices"]'] },
      "razorpay.payment_button": { hideElementsCSS: ['a[href="/app/paymentbuttons"]'] },
      "razorpay.subscriptions": { hideElementsCSS: ['a[href="/app/subscriptions"]'] },
      "razorpay.smart_collect": { hideElementsCSS: ['a[href="/app/smartcollect/virtualaccounts"]'] },
      "razorpay.optimizer": { hideElementsCSS: ['a[href="/app/optimizer"]'] },
      "razorpay.account_settings": { hideElementsCSS: ['a[href="/app/account-settings"]'] }
    },
    otp: {
      type: "EMAIL",
      inputSelector: 'input[name="otp"], input[autocomplete="one-time-code"], input[inputmode="numeric"][maxlength="1"], input[type="number"][maxlength="1"]',
      // Specific selectors first. button[type="submit"] is the safe fallback since
      // after all 6 digits are filled, the only submit-type button on this page is Verify.
      // We deliberately removed button:not([disabled]) as it matched Resend/Back first.
      submitSelector: 'button[data-testid="btn-verify"], button[data-testid="verify-btn"], button[type="submit"]'
    }
  });
  platformRegistry.register({
    id: "LINKEDIN",
    name: "LinkedIn",
    domains: ["linkedin.com"],
    login: {
      url: "https://www.linkedin.com/login",
      usernameSelector: 'input[name="session_key"], input#username, input[type="text"]:not([placeholder*="Search" i]):not(.search-global-typeahead__input), input[type="email"]',
      passwordSelector: 'input[name="session_password"], input#password, input[type="password"]',
      submitSelector: 'button[type="submit"], input[type="submit"], button[data-litms-control-urn="login-submit"]'
    },
    hideElementsCSS: [
      'input[type="password"][autocomplete="current-password"]',
      'button[aria-label="Show password" i]',
      "button:has(svg#visibility-small)",
      'div:has(> input[type="password"][autocomplete="current-password"])'
    ],
    capabilityRestrictions: {
      "linkedin.my_network": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/mynetwork"]']
      },
      "linkedin.jobs": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/jobs"]']
        // Inferred from pattern
      },
      "linkedin.messaging": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/messaging"]']
      },
      "linkedin.notifications": {
        hideElementsCSS: ['a[href^="https://www.linkedin.com/notifications"]']
      },
      "linkedin.page_dashboard": {
        hideElementsCSS: ['[data-test-org-menu-item="HOME"]']
      },
      "linkedin.page_posts": {
        hideElementsCSS: ['[data-test-org-menu-item="POSTS"]']
      },
      "linkedin.page_analytics": {
        hideElementsCSS: ['[data-test-org-menu-item="ANALYTICS"]']
      },
      "linkedin.page_feed": {
        hideElementsCSS: ['[data-test-org-menu-item="FEED"]']
      },
      "linkedin.page_activity": {
        hideElementsCSS: ['[data-test-org-menu-item="ACTIVITY"]']
      },
      "linkedin.page_inbox": {
        hideElementsCSS: ['[data-test-org-menu-item="INBOX"]']
      },
      "linkedin.page_services": {
        hideElementsCSS: ['[data-test-org-menu-item="SERVICES"]']
      },
      "linkedin.page_posted_jobs": {
        hideElementsCSS: ['[data-test-org-menu-item="POSTED_JOBS"]']
      },
      "linkedin.page_edit": {
        hideElementsCSS: ['[data-test-org-menu-item="EDIT"]']
      },
      "linkedin.page_settings": {
        hideElementsCSS: ['[data-test-org-menu-item="SETTINGS"]']
      },
      "linkedin.page_advertise": {
        hideElementsCSS: ['[data-test-org-menu-item="ADVERTISE"]']
      }
    }
  });
  platformRegistry.register({
    id: "MCA",
    name: "MCA Portal",
    domains: ["www.mca.gov.in", "mca.gov.in"],
    login: {
      url: "https://www.mca.gov.in/content/mca/global/en/foportal/fologin.html",
      // User ID: accepts CIN/LLPIN/FCRN for companies or email for other users.
      // NOTE: input[type="text"] or form-based fallbacks are BANNED here.
      // The MCA header contains a search bar form that appears before the login
      // form in the DOM, so generic fallbacks will match the search bar.
      usernameSelector: [
        'input[name="userID" i]',
        // exact match from DOM (case-insensitive)
        'input[name="userId" i]',
        'input[name="loginid" i]',
        ".userID input",
        // wrapper class from DOM
        ".user-id-input input"
        // wrapper class from DOM
      ].join(", "),
      passwordSelector: [
        'input[type="password"]',
        'input[name="password"]',
        'input[id="password"]'
      ].join(", ")
      // No submitSelector — manualStepMessage prevents auto-submit
    },
    manualStepMessage: "WithUs Vault: Secure session activated. Please resolve the CAPTCHA to proceed.",
    capabilityRestrictions: {
      "mca.master_data": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/master-data.html"])'] },
      "mca.llp_efiling": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/llp-e-filling.html"])'] },
      "mca.fo_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/fo-llp-services.html"])'] },
      "mca.dsc_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/dsc-services-v3.html"])'] },
      "mca.company_efiling": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/e-filing.html"])'] },
      "mca.complaints": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/complaints.html"])'] },
      "mca.document_related_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/document-related-services.html"])'] },
      "mca.payment_services": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/fee-and-payment-services.html"])'] },
      "mca.id_databank": { hideElementsCSS: ['li.level-1:has(> a[href$="/mca/id-databank-services.html"])'] }
    }
  });
  platformRegistry.register({
    id: "GST",
    name: "GST Portal",
    domains: ["gst.gov.in", "services.gst.gov.in"],
    login: {
      url: "https://services.gst.gov.in/services/login",
      // Specific name/id selectors only Ã¢â‚¬â€ intentionally exclude input[type="text"]
      // to prevent matching the CAPTCHA field which is also type=text on this page.
      usernameSelector: [
        "#user_name",
        'input[name="user_name"]',
        'input[id="user_name"]',
        'input[name="username"]',
        'input[id="username"]'
      ].join(", "),
      passwordSelector: [
        "#user_pass",
        // Exact ID match based on DOM snippet
        'input[name="user_pass"]',
        // GST-specific: confirmed from portal DOM
        'input[id="user_pass"]',
        'input[type="password"]',
        // standard fallback
        'input[name="password"]'
      ].join(", ")
      // No submitSelector — manualStepMessage prevents auto-submit
    },
    capabilityRestrictions: {
      "gst.registration": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/registration"]']
      },
      "gst.ledgers": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/ledgers"]']
      },
      "gst.returns": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/returns"]']
      },
      "gst.payments": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/payments"]']
      },
      "gst.refunds": {
        hideElementsCSS: ['a[href*="/services/auth/quicklinks/refunds"]']
      }
    },
    manualStepMessage: "Credentials filled. Please complete the CAPTCHA and OTP verification to continue."
  });
  platformRegistry.register({
    id: "UDYAM",
    name: "Udyam Portal",
    domains: ["udyamregistration.gov.in"],
    login: {
      url: "https://udyamregistration.gov.in",
      usernameSelector: [
        'input[name="udyam_no"]',
        'input[id="udyam_no"]',
        'input[name="Udyam_No"]',
        'input[name="udyamNo"]',
        'input[placeholder*="Udyam" i]',
        'input[placeholder*="Registration Number" i]',
        'input[maxlength="19"]'
        // Registration numbers are exactly 19 chars
      ].join(", ")
      // No passwordSelector — mobile number is NOT represented here.
      // Architecture Preservation Directive: do not overload passwordSelector semantics.
    },
    manualStepMessage: 'Udyam Registration Number filled. Please enter your mobile number and click "Validate & Generate OTP" to receive your OTP.',
    capabilityRestrictions: {
      "udyam.cancellation": {
        hideElementsCSS: ['a[href="Udyam_Cancellation.aspx"]']
      },
      "udyam.print_certificate": {
        hideElementsCSS: ["#ctl00_ContentPlaceHolder1_btnPrintC"]
      },
      "udyam.edit_details": {
        hideElementsCSS: ["#ctl00_ContentPlaceHolder1_btnEdit"]
      }
    }
  });
  platformRegistry.register({
    id: "GMAIL",
    name: "Gmail",
    domains: ["mail.google.com", "accounts.google.com"],
    login: {
      url: "https://mail.google.com",
      usernameSelector: 'input#identifierId, input[name="identifier"], input[type="email"]',
      passwordSelector: 'input[name="Passwd"], input[name="password"], input[type="password"]',
      submitSelector: 'div#identifierNext button, div#passwordNext button, button[type="submit"]'
    },
    // Only hide the "Show password" row — never hide the actual password input.
    // Hiding input[type="password"] creates a black box (display:none kills the bullets).
    // Hiding div:has(> input[type="password"]) accidentally matches on page 1 too because
    // Google pre-renders a hidden password field in the DOM on the email step.
    //
    // Show password selectors confirmed from live DOM:
    //   div[jsname="wQNmvb"] — the entire "Show password" checkbox row (new Google UI)
    //   button[jsname="M1Kmfa"] — legacy eye-icon button (fallback for older Google UI)
    hideElementsCSS: [
      'div[jsname="wQNmvb"]',
      // "Show password" checkbox row — new Google UI
      'button[jsname="M1Kmfa"]'
      // "Show password" eye icon — legacy Google UI fallback
    ],
    // No manualStepMessage for Gmail.
    // Email and password are on two separate Google-hosted pages (hard navigations).
    // The content script auto-fills and auto-submits each step in sequence:
    //   Page 1 (identifier): fill email → click div#identifierNext button
    //   Page 2 (challenge):  fill password → click div#passwordNext button
    // If Google then shows 2-Step Verification, the user completes it manually.
    // Adding manualStepMessage would block auto-submit on BOTH steps, leaving the
    // member stuck with a filled-but-unsubmitted form — worse UX than letting it flow.
    capabilityRestrictions: {
      "gmail.compose": {
        // Gmail Compose button — [gh="cm"] is the most stable attribute, but we also include 
        // class names and wrapper selectors to ensure the button and its container are fully hidden.
        hideElementsCSS: ['div[gh="cm"]', ".T-I-KE", 'div[jscontroller="eIu7Db"]', 'div:has(> div[gh="cm"])']
      },
      "gmail.inbox": {
        hideElementsCSS: ['a[href*="#inbox"]', 'div.aim:has(a[href*="#inbox"])']
      },
      "gmail.starred": {
        hideElementsCSS: ['a[href*="#starred"]', 'div.aim:has(a[href*="#starred"])']
      },
      "gmail.snoozed": {
        hideElementsCSS: ['a[href*="#snoozed"]', 'div.aim:has(a[href*="#snoozed"])']
      },
      "gmail.sent": {
        // Gmail sidebar Sent folder link.
        hideElementsCSS: ['a[href*="#sent"]', 'div.aim[data-tooltip*="Sent" i]', 'div.aim:has(a[href*="#sent"])']
      },
      "gmail.drafts": {
        hideElementsCSS: ['a[href*="#drafts"]', 'div.aim:has(a[href*="#drafts"])']
      },
      "gmail.purchases": {
        hideElementsCSS: ['a[href*="#category/purchases"]', 'div.aim:has(a[href*="#category/purchases"])']
      },
      "gmail.important": {
        hideElementsCSS: ['a[href*="#imp"]', 'div.aim:has(a[href*="#imp"])']
      },
      "gmail.scheduled": {
        hideElementsCSS: ['a[href*="#scheduled"]', 'div.aim:has(a[href*="#scheduled"])']
      },
      "gmail.all_mail": {
        hideElementsCSS: ['a[href*="#all"]', 'div.aim:has(a[href*="#all"])']
      },
      "gmail.spam": {
        hideElementsCSS: ['a[href*="#spam"]', 'div.aim:has(a[href*="#spam"])']
      },
      "gmail.trash": {
        // Gmail sidebar Trash/Bin folder link.
        hideElementsCSS: ['a[href*="#trash"]', 'div.aim[data-tooltip*="Trash" i]', 'div.aim[data-tooltip*="Bin" i]', 'div.aim:has(a[href*="#trash"])']
      },
      "gmail.labels": {
        // Label and subscription management menu in Gmail sidebar.
        hideElementsCSS: ['a[href*="#settings/labels"]', 'a[href*="#subscriptions"]', 'div.aim:has(a[href*="#settings/labels"])', 'div.aim:has(a[href*="#subscriptions"])']
      },
      "gmail.settings": {
        // Gmail settings gear icon (top-right of inbox).
        hideElementsCSS: ['div[data-tooltip*="Settings" i].FH', 'div[aria-label*="Settings" i].FH']
      },
      "gmail.contacts": {
        // Google Contacts link in Gmail's apps/sidebar.
        hideElementsCSS: ['a[href*="contacts.google.com"]']
      }
    }
  });
  platformRegistry.register({
    id: "GOOGLE_ADS",
    name: "Google Ads",
    domains: ["ads.google.com", "accounts.google.com"],
    login: {
      url: "https://ads.google.com/",
      usernameSelector: 'input[type="email"], input[name="identifier"], input#identifierId'
      // Deliberately omitting passwordSelector to respect the frozen architecture
      // and prevent breaking on Google's two-step flow and passkey mandates.
    },
    manualStepMessage: 'Email filled. Google requires manual sign-in due to passkey / 2FA / account chooser. Click "Next" and continue manually.'
  });

  // src/content/capability-enforcer.ts
  function sendMessage(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (response) => {
        resolve(response || { success: false, error: "No response from background" });
      });
    });
  }
  if (!window.__WITHUS_ENFORCER_LOADED__) {
    window.__WITHUS_ENFORCER_LOADED__ = true;
    initEnforcer();
  }
  var WITHUS_CACHE_KEY = "withus_cap_cache_v1";
  function injectCSS(config, restrictions) {
    if (!config)
      return;
    const styleId = "withus-capability-enforcer-css";
    const stylesToInject = [];
    for (const cap of restrictions) {
      const rule = config.capabilityRestrictions?.[cap];
      if (rule?.hideElementsCSS)
        stylesToInject.push(...rule.hideElementsCSS);
    }
    if (stylesToInject.length === 0)
      return;
    let styleEl = document.getElementById(styleId);
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = styleId;
      if (document.head) {
        document.head.appendChild(styleEl);
      } else {
        document.documentElement.appendChild(styleEl);
      }
    }
    styleEl.textContent = stylesToInject.map((sel) => `${sel} { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; }`).join("\n");
  }
  async function initEnforcer() {
    const config = platformRegistry.getForHost(location.hostname);
    if (!config || !config.capabilityRestrictions) {
      return;
    }
    try {
      const cached = await chrome.storage.session.get(WITHUS_CACHE_KEY);
      const cachedRestrictions = cached[WITHUS_CACHE_KEY];
      if (cachedRestrictions && cachedRestrictions.length > 0) {
        injectCSS(config, cachedRestrictions);
      }
    } catch (_) {
    }
    const response = await sendMessage({
      type: "GET_ACTIVE_SESSION",
      payload: { domain: location.hostname }
    });
    if (!response.success || !response.data?.sessions.length) {
      chrome.storage.session.remove(WITHUS_CACHE_KEY).catch(() => {
      });
      document.getElementById("withus-capability-enforcer-css")?.remove();
      return;
    }
    const session = response.data.sessions[0];
    let restrictionsToApply = [];
    if (config.id === "MCA") {
      let mcaRestricted = session.mcaRestrictedModules;
      if (!mcaRestricted && Array.isArray(session.capabilities)) {
        const MCA_TOP_LEVEL_MODULES = ["mca.master_data", "mca.llp_efiling", "mca.fo_services", "mca.dsc_services", "mca.company_efiling", "mca.complaints", "mca.document_related_services", "mca.payment_services", "mca.id_databank"];
        mcaRestricted = MCA_TOP_LEVEL_MODULES.filter((mod) => !session.capabilities.includes(mod));
      }
      if (!mcaRestricted || mcaRestricted.length === 0) {
        chrome.storage.session.remove(WITHUS_CACHE_KEY).catch(() => {
        });
        document.getElementById("withus-capability-enforcer-css")?.remove();
        return;
      }
      restrictionsToApply = mcaRestricted;
    } else {
      if (!session.capabilities || session.capabilities.length === 0) {
        chrome.storage.session.remove(WITHUS_CACHE_KEY).catch(() => {
        });
        document.getElementById("withus-capability-enforcer-css")?.remove();
        return;
      }
      const allPlatformCaps = Object.keys(config.capabilityRestrictions);
      const restricted = allPlatformCaps.filter((cap) => !session.capabilities.includes(cap));
      if (restricted.length === 0) {
        chrome.storage.session.remove(WITHUS_CACHE_KEY).catch(() => {
        });
        document.getElementById("withus-capability-enforcer-css")?.remove();
        return;
      }
      restrictionsToApply = restricted;
    }
    chrome.storage.session.set({ [WITHUS_CACHE_KEY]: restrictionsToApply }).catch(() => {
    });
    const stylesToInject = [];
    const restrictedRoutes = [];
    const allowedRoutes = [];
    for (const cap of restrictionsToApply) {
      const restriction = config.capabilityRestrictions[cap];
      if (restriction) {
        if (restriction.hideElementsCSS) {
          stylesToInject.push(...restriction.hideElementsCSS);
        }
        if (restriction.restrictedRoutePatterns) {
          restrictedRoutes.push(...restriction.restrictedRoutePatterns);
        }
        if (restriction.allowedRoutePatterns) {
          allowedRoutes.push(...restriction.allowedRoutePatterns);
        }
      }
    }
    if (stylesToInject.length === 0 && restrictedRoutes.length === 0) {
      return;
    }
    if (stylesToInject.length > 0) {
      injectCSS(config, restrictionsToApply);
      if (config.id === "LINKEDIN") {
        if (!window.__WITHUS_OBSERVER_LOADED__) {
          window.__WITHUS_OBSERVER_LOADED__ = true;
          const styleId = "withus-capability-enforcer-css";
          const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
              if (mutation.type === "childList") {
                for (let i = 0; i < mutation.removedNodes.length; i++) {
                  const removedNode = mutation.removedNodes[i];
                  if (removedNode instanceof HTMLStyleElement && removedNode.id === styleId) {
                    injectCSS(config, restrictionsToApply);
                  }
                }
                for (let i = 0; i < mutation.addedNodes.length; i++) {
                  const addedNode = mutation.addedNodes[i];
                  if (addedNode instanceof HTMLHeadElement) {
                    injectCSS(config, restrictionsToApply);
                    observer.observe(addedNode, { childList: true });
                  }
                }
              }
            }
          });
          const attachObserver = () => {
            if (document.head)
              observer.observe(document.head, { childList: true });
            if (document.documentElement)
              observer.observe(document.documentElement, { childList: true });
          };
          if (document.head) {
            attachObserver();
          } else {
            window.addEventListener("DOMContentLoaded", attachObserver, { once: true });
          }
        }
      }
    }
    if (restrictedRoutes.length > 0 || allowedRoutes.length > 0) {
      enforceRoute(location.href, restrictedRoutes, allowedRoutes);
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;
      history.pushState = function(...args) {
        const url = args[2];
        if (url && typeof url === "string") {
          const fullUrl = new URL(url, location.origin).href;
          if (isRouteRestricted(fullUrl, restrictedRoutes, allowedRoutes)) {
            showRestrictedToast();
            return;
          }
        }
        return originalPushState.apply(this, args);
      };
      history.replaceState = function(...args) {
        const url = args[2];
        if (url && typeof url === "string") {
          const fullUrl = new URL(url, location.origin).href;
          if (isRouteRestricted(fullUrl, restrictedRoutes, allowedRoutes)) {
            showRestrictedToast();
            return;
          }
        }
        return originalReplaceState.apply(this, args);
      };
      window.addEventListener("popstate", () => {
        enforceRoute(location.href, restrictedRoutes, allowedRoutes);
      });
    }
  }
  function isRouteRestricted(urlStr, restricted, allowed) {
    try {
      const url = new URL(urlStr, location.origin);
      const pathAndHash = url.pathname + url.hash;
      for (const pattern of restricted) {
        if (pathAndHash.includes(pattern)) {
          return true;
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }
  function enforceRoute(urlStr, restricted, allowed) {
    if (isRouteRestricted(urlStr, restricted, allowed)) {
      showRestrictedToast();
      const safeRoute = allowed.length > 0 ? allowed[0] : "/";
      location.replace(safeRoute);
    }
  }
  function showRestrictedToast() {
    let toast = document.getElementById("withus-restriction-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "withus-restriction-toast";
      toast.style.cssText = [
        "position:fixed",
        "top:24px",
        "right:24px",
        "z-index:2147483647",
        "background:#dc3545",
        "color:#ffffff",
        "border-radius:8px",
        "padding:12px 20px",
        "font-family:system-ui,sans-serif",
        "font-size:14px",
        "font-weight:600",
        "box-shadow:0 10px 40px rgba(0,0,0,0.5)",
        "transition:opacity 0.3s ease",
        "pointer-events:none"
      ].join(";");
      toast.textContent = "Access Restricted by Administrator";
      document.body.appendChild(toast);
    }
    toast.style.opacity = "1";
    setTimeout(() => {
      toast.style.opacity = "0";
    }, 3e3);
  }
})();
